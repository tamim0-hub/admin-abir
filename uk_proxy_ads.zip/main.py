
from flask import Flask, request, redirect, Response
import requests

app = Flask(__name__)

@app.route('/proxy')
def proxy():
    target_url = request.args.get('url')
    if not target_url:
        return "No URL provided", 400

    headers = {
        "X-Forwarded-For": "51.140.0.1",  # Fake UK IP
        "User-Agent": request.headers.get('User-Agent', 'Mozilla/5.0')
    }

    resp = requests.get(target_url, headers=headers)
    return Response(resp.content, content_type=resp.headers.get('Content-Type'))

@app.route('/')
def index():
    return '''
        <html>
        <head><title>UK Ads Proxy</title></head>
        <body>
            <h2>Ad Proxy Running via UK IP</h2>
            <iframe src="/proxy?url=https://example.com" width="100%" height="500"></iframe>
        </body>
        </html>
    '''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
